﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace MultiDataContextMigrations.Models
{
    public class Order
    {
        public int OrderID { set; get; }
        public int Quantity { set; get; }
        public double Amount { set; get; }
        public DateTime Date { set; get; }
    }
}