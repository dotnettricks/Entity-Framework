﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MultiDataContextMigrations.Models
{
    public class Role
    {
        public int RoleID { set; get; }
        public string RolesName { set; get; }
    }
}